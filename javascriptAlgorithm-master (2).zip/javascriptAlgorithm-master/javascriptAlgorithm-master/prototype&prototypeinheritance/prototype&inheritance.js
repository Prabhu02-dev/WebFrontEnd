let person = {
  name: "prakash",
  city: "trichy",
  display: function () {
    console.log(this.name + " " + this.city);
  },
};

let person1 = {
  name: "akshai",
  city: "chennai",
};
person.__proto__ = person1;
Function.prototype.myfunc = function () {
  console.log("hello world");
  return 0;
};

function func1() {}
console.log(func1.myfunc());
function func2() {}
console.log(func2.myfunc());
