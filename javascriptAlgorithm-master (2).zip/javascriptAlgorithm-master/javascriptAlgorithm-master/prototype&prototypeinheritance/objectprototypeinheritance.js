let fruits = function (color) {
  this.color = color;
  //console.log('Its in'+" "+this.color)
};

fruits.prototype.introduce = function () {
  console.log("I am " + this.color);
};

let apple = function (color) {
  fruits.call(this, color);
};
apple.prototype = Object.create(fruits.prototype);
let fruit = new fruits("red");
let a = new apple("green");
fruit.introduce();
a.introduce();

console.log("gap");
let Alligator = function (color) {
  this.color = color;
};

Alligator.prototype.introduce = function () {
  console.log("I am " + this.color);
};

let Croc = function (color) {
  Alligator.call(this, color);
};

Croc.prototype = Object.create(Alligator.prototype);

let alligatorObj = new Alligator("green");
let crocObj = new Croc("yellow");

alligatorObj.introduce(); // I am green
crocObj.introduce(); // I am yellow
