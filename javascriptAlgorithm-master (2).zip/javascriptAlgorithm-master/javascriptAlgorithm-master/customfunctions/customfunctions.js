Array.prototype.myUcase = function (x) {
  for (i = 0; i < x.length; i++) {
    x[i] = x[i].toUpperCase();
  }
};
Array.prototype.FEach = function (arr) {
  for (let i = 0; i < arr.length; i++) console.log(arr[i]);
};

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.myUcase(this);
fruits.FEach(this);
console.log(fruits);

Array.prototype.mymap = function (callback) {
  const resultArray = [];
  console.log(callback);
  console.log(this);
  for (let index = 0; index < this.length; index++) {
    console.log(callback(this[index], index, this));
    resultArray.push(callback(this[index], index, this));
  }
  return resultArray;
};
const sample = [1, 2, 3];
var output = sample.mymap(function (val, index, array) {
  console.log("val", val, "index", index, "array:", array);
  return val * 2;
});
Array.prototype.myfilter = function (callback) {
  const filterArray = [];
  for (let index = 0; index < this.length; index++) {
    filterArray.push(callback(this[index], index, this));
  }
  return filterArray;
};

var output = sample.myfilter(function (val, index, array) {
  console.log("val", val, "index", index, "array:", array);
  return val % 2 == 0;
});

Array.prototype.myreduce = function (callback) {
  let sum = 0;
  for (let index = 0; index < this.length; index++) {
    sum += callback(this[index], index, this);
  }
  return sum;
};
var output = sample.myreduce(function (val, index, array) {
  console.log("val", val, "index", index, "array:", array);
  return val;
});

var person = {
  fullName: function (city, country) {
    return this.firstName + " " + this.lastName + "," + city + "," + country;
  },
};
console.log("call");
var person1 = {
  firstName: "John",
  lastName: "Doe",
};
Function.prototype.mycall = function (x, b, c) {
  x.fname = this;
  console.log(x.fname(b, c));
};
person.fullName.mycall(person1, "hello", "world");
console.log("apply");
var person2 = {
  firstName: "John",
  lastName: "Doe",
};
Function.prototype.myapply = function (x, ...arg) {
  console.log(this);
  x.fname = this;
  let arg1 = [];

  console.log(...arg);
  for (let i = 0; i < arg.length; i++) arg1.push(arg[i]);
  console.log(x.fname(arg1));
};
person.fullName.myapply(person2, ["hello", "world"]);
console.log("bind");
let name = {
  firstname: "pk",
  lastname: "murthy",
};
let printName = function (hometown, state) {
  console.log(this);
  console.log(this.firstname + "" + this.lastname + hometown + state);
};

Function.prototype.mybind = function (x, ...arg) {
  x.fname = this;
  console.log(this);
  return function (...args2) {
    x.fname(arg[0], args2[0]);
  };
};
let printmyname2 = printName.mybind(name, "chennai");
console.log(printmyname2);
printmyname2("tamilnadu");
