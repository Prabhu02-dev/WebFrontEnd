let comp_arr = ["fb", "amazon", "google"];
for (let c of comp_arr) console.log(c);

let d = comp_arr[Symbol.iterator]();
console.log(d.next());

let comp_obj = { x: "fb", y: "amazon", z: "google" };
for (let c in comp_obj) console.log(comp_obj[c]);
console.log(Object.Values(comp_obj));
