console.log(x);
var x = 10;
//console.log(y);
let y = 10;
{
  let y = 10;
}
for (let i = 0; i < 10; i++) {
  console.log(i);
}
//console.log(i);
console.log(x);
function xy() {
  var a = 10;
  console.log(a);
}
xy();
console.log(a);
