function f() {
  let a = (b = 0);
}
f();
//console.log(a);
console.log(b);