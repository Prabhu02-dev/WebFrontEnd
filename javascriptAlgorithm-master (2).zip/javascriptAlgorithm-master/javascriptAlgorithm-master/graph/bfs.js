// Breath First Search
// - Visit neighbors at current depth first.!


// Psudocode - BFS
// the function should accept the start vertex
// create queue (you can use an array) and place the starting vertex in it
// create an array to store the nodes visited
// create an object to store nodes visited
// mark the starting vertex as visited
// loop as long as there is anything in queue
// removee the first vertex from the queue and push it into the array that stores nodes visited
// loop over every vertex in the adjency list for the vertex you are visiting
// if it is noy inside the object that stores nodes visited, mark it as visited and
//      enqueu that vertex

