function printString(string) {
  return new Promise((resolve, reject) => {
    setTimeout(function () {
      console.log("this" + string);
      resolve(string);
    }, Math.floor(Math.random() * 100) + 1);
  });
}
let pr1 = printString("A").then((d) => console.log(d));
let pr2 = printString("B").then((d) => console.log(d));
let pr3 = printString("C").then((d) => console.log(d));
Promise.race([pr1, pr2, pr3]).then(() => console.log("helloworld"));
