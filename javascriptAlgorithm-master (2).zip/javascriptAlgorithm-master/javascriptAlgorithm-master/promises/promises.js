function printString(string) {
  return new Promise((resolve, reject) => {
    setTimeout(function () {
      console.log("this" + string);
      resolve(string);
    }, Math.floor(Math.random() * 100) + 1);
  });
}
printString("A1").then(function (val) {
  console.log(val);
  printString("B2").then(function (val) {
    console.log(val);
    printString("C3").then((val) => console.log(val));
  });
});
console.log("hello");

function delay(time) {
  return new Promise((resolve, reject) => {
    setTimeout(resolve(), time);
  });
}
delay(1000)
  .then(function () {
    console.log("hello-world");
  })
  .catch((err) => console.error(err));
console.log("cb");
/*
function printString1(string,cb){
    setTimeout(function(){
      console.log(cb);
      console.log(string);
      cb();
      },
     Math.floor(Math.random() * 100) + 1)
    }
  
printString1("A",function(){printString1("B",function(){printString1("C")})});*/

console.log("await");
async function printString2(string) {
  let my = new Promise((resolve, reject) => {
    setTimeout(function () {
      resolve(string);
    }, Math.floor(Math.random() * 100) + 1);
  });
  //console.log(my);
  return await my;
}
printString2("Aa").then(function (val) {
  console.log(val);
  printString2("Bb").then(function (val) {
    console.log(val);
    printString2("Cc").then((val) => console.log(val));
  });
});

console.log("end");
