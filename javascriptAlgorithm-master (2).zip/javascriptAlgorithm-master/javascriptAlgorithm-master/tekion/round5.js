//Find the deepest key in the object. Sample Input: {
var obj = {
  a: {
    b: {
      c: {},
      d: { e: {} },
      f: { g: { h: {} } },
    },
  },
};

var max = null;
var resultMax = null;
function calc(obj, gen, cache) {
  var result = null;
  for (var ke in obj) {
    var value = obj[ke];
    if (
      typeof value != null &&
      typeof value === "object" &&
      Object.keys(value).length > 0
    ) {
      var updatedResult = calc(value, gen + 1, cache);
      result = updatedResult && updatedResult.result;
    } else {
      result = cache && cache.previousDeepestKey;
    }
  }

  if (!cache.deepGen) {
    cache.deepGen = gen;
    cache.previousDeepestKey = result;
  }

  if (cache.deepGen > gen) {
    return cache.previousDeepestKey;
  }
  return result;
}

function getDeepestKey(myobj) {
  var result = null;
  var cache = {};
  for (var ke in myobj) {
    result = calc(myobj[ke], 1, cache);
  }
  return result;
}
