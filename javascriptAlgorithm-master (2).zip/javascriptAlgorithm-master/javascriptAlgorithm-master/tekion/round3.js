function employeer(a, b) {
  return this.name + " " + this.manager + " " + a + " " + b;
}

var employee = {
  name: "prakash",
  manager: "abcd",
};
//employeer.__proto__=employee;
//console.log(employeer);
Function.prototype.mycall = function (x, ...arg) {
  x.printname = this;
  console.log(x.printname(arg[0], arg[1]));
};
employeer.mycall(employee, "hello", "world");

console.log("break to debounce");
let counter = 0;
function getData() {
  console.log("fetch data", counter++);
}
function debounce(func, delay) {
  let timer;
  console.log(val);
  return function () {
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (val == "") {
        clearTimeout(timer);
        timer = setTimeout(() => {
          func();
        }, 3000);
      } else func();
    }, delay);
  };
}

const getOptData = () => {
  debounce(getData, 3000);
};
/*
function getOptData(event){
	return debounce(getData,3000,e.target.value);
}*/
// 1.Mounting
// -constructor()
// -getDerievedStatefromProps()
// -render()
// -componentDidMount()
// 2.Updating
// -this.setstate(),forceupdate()
// -getDerievedStatefromProps()
// -shouldComponentUpdate(ps,cs)
// -render()
// -getSnapshotBeforeUpdate(ps,pp)
// -componentdidupdate()
// 3.unmounting
// -componentWillunmount()
