console.log("question1");
let a = "+D+=3=+s+$%+p-";
let b = a.split("");
var flag = 0;
console.log(b);
for (let i = 1; i < b.length; i++) {
  if (b[i].match(/[a-z]/i) !== null) {
    if (b[i - 1] == "+" && b[i + 1] == "+") {
      console.log(b[i]);
      continue;
    } else {
      flag = 1;
      break;
    }
  }
}
if (flag == 0) console.log("Valid string");
else console.log("Invalid string");
console.log("question2");
