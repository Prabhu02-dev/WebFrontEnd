var a = [
  {
    tagId: "5f06f77dac9872fa85db2610",
    tagName: "tap-release-1.2.0",
    description: "",
  },
  {
    tagId: "5f06f77dac9872fa85db2610",
    tagName: "tap-release-1.2.0",
    description: "",
  },
];

Array.prototype.mykeys = function () {
  let out = [];
  console.log(this);
  a.map((i) => {
    console.log("hei");
    console.log(i);
    for (k in i) console.log(k);
    //console.log(i[k])
  });
};
a.mykeys();

var b = [
  "Hai, Hello, How, Are, You",
  "Hai, Welcome, How, About, You",
  "Hai, You",
  "Welcome",
];
var out = [];
for (let i = 0; i < b.length; i++) {
  let c = b[i].split(",");
  for (let j = 0; j < c.length; j++) out.push(c[j].trim());
}
console.log(out);
out1 = [];
for (let k = 0; k < out.length; k++) {
  for (let l = k + 1; l < out.length; l++) {
    if (out[k] == out[l]) out1.push(out[k]);
  }
}
console.log(out1);

const counts = {};
for (var i = 0; i < out1.length; i++) {
  counts[out1[i]] = 1 + (counts[out1[i]] || 0);
}
console.log(counts);
for (let k in counts) console.log(k);
console.log("Q2 ans");
var o = { a: { d: "1" }, b: { e: { f: "2" } }, c: { g: { h: { i: "3" } } } };
for (let i in o) {
  let c = o[i];
  if (typeof c === "object") {
    for (let j in c) {
      if (typeof c[j] === "object") {
        c = c[j];
        //console.log("hi");
        console.log(c[j]);
        continue;
      } else console.log(c);
      break;
    }
  }

  console.log(c);
}
console.log("brea");
var o = { a: { d: 1 }, b: { e: { f: 2 } }, c: { g: { h: { i: 3 } } } };
console.log(Object.keys(o));
