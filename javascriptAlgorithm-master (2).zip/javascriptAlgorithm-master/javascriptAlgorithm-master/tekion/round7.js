var input = {};
var maxNode = { key: "", weight: "" };
var output = getDeepestKey(input);
console.log(output.key);
function getDeepestKey(input) {
  for (var a in input) {
    var sibiling = getSubChildren(input[a], 1);
    weightCheck(sibiling);
  }
  return maxNode;
}

function getSubChildren(children, count) {
  for (var child in children) {
    if (
      typeof children[child] === "object" &&
      Object.keys(children[child]).length
    ) {
      getSubChildren(children[child], count + 1);
    } else {
      weightCheck({ key: child, weight: count });
    }
  }
  return maxNode;
}

function weightCheck(lastChild) {
  if (maxNode.weight < lastChild.weight) {
    maxNode.key = lastChild.key;
    maxNode.weight = lastChild.weight;
  }
}
