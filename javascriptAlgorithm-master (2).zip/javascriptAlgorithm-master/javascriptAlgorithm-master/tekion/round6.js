var data = [
  "hai, Hello, How, Are, You",
  "Hai, Welcome, How, About, You",
  "Hai, You",
  "Welcome",
  "hai",
];

function getMostReWord(arr) {
  var result = [];

  var allWords = arr.reduce((acc, current) => {
    var words = current.split(",").map((char) => char.trim());
    return [...acc, ...words];
  }, []);

  var allWordsCache = {};
  allWords.forEach((all) => {
    var currentKey = all.toLowerCase();
    if (currentKey in allWordsCache) {
      var currentRes =
        allWordsCache[currentKey] &&
        Array.isArray(allWordsCache[currentKey].allCases)
          ? allWordsCache[currentKey].allCases.find((fi) => fi.key == all)
          : null;
      if (currentRes) {
        currentRes.key = all;
        currentRes.count = currentRes.count + 1;
      } else {
        if (allWordsCache[currentKey]) {
          allWordsCache[currentKey].allCases = [
            ...allWordsCache[currentKey].allCases,
            {
              key: all,
              count: 1,
            },
          ];
        } else {
          allWordsCache[currentKey] = {
            allCases: [
              {
                key: all,
                count: 1,
              },
            ],
          };
        }
      }
      var myCount = allWordsCache[currentKey].count + 1;
      allWordsCache[currentKey] = {
        ...allWordsCache[currentKey],
        count: myCount,
      };
    } else {
      var currentRes =
        allWordsCache[currentKey] &&
        Array.isArray(allWordsCache[currentKey].allCases)
          ? allWordsCache[currentKey].allCases.find((fi) => fi.key == all)
          : null;
      if (currentRes) {
        currentRes.key = all;
        currentRes.count = currentRes.count + 1;
        currentKey.isPrimary = true;
      } else {
        allWordsCache[currentKey] = { allCases: [] };
        allWordsCache[currentKey].allCases = [
          ...allWordsCache[currentKey].allCases,
          {
            key: all,
            count: 1,
            isPrimary: true,
          },
        ];
      }

      allWordsCache[currentKey] = { ...allWordsCache[currentKey], count: 1 };
    }
  });

  console.log(allWordsCache);
  var maxreKey = "";
  var maxRepeat = 0;
  for (var wo in allWordsCache) {
    var re = allWordsCache[wo].count;
    if (re > maxRepeat) {
      maxRepeat = re;
    }
  }

  for (var last in allWordsCache) {
    if (allWordsCache[last].count == maxRepeat) {
      result.push(last);
    }
  }

  return filterResult(result, allWordsCache);
}

function filterResult(result, cache) {
  var updatedResult = [];
  result.forEach((res) => {
    var currentCache = cache[res];
    if (
      currentCache &&
      currentCache.allCases &&
      currentCache.allCases.length == 1
    ) {
      updatedResult.push(res);
    } else {
      var allCase = currentCache && currentCache.allCases;
      if (allCase[0].count > allCase[1].count) {
        updatedResult.push(allCase[0].key);
      } else if (allCase[0].count == allCase[1].count) {
        var primary = allCase[0].isPrimary ? allCase[0].key : allCase[1].key;
        updatedResult.push(primary);
      } else {
        updatedResult.push(allCase[1].key);
      }
    }
  });
  return updatedResult;
}
