let d = "arrb6???4xxbl5????eee6";
let e = d.split("");
console.log(e);
var flag = 0;
for (let j = 0; j < e.length; j++) {
  if (e[j].match(/[0-9]/) !== null) {
    let f = [];
    f.push(e[j]);
    for (let k = j + 1; k < e.length; k++) {
      f.push(e[k]);
      console.log(f);
      if (e[k].match(/[0-9]/) !== null) {
        let count = 0;
        //console.log(e[k]);
        for (let g = 0; g < f.length; g++) {
          if (f[g] === "?") count = count + 1;
        }
        //console.log(count);
        if (count == 3) {
          var sum = 0;
          for (let g = 0; g < f.length; g++) {
            if (f[g].match(/[0-9]/) !== null) sum += parseInt(f[g]);
          }
          if (sum == 10) {
            console.log(sum);
            let m = f[f.length - 1];
            f = [];
            f.push(m);
            console.log("Sum equals to 10");
          } else {
            console.log("Sum doesnt equal to 10");
            flag = 1;
          }
        } else {
          console.log("three question marks not there");
        }

        sum = 0;
        // console.log(sum);
        let m = f[f.length - 1];
        f = [];
        f.push(m);
      }
    }
  }
}
if (flag == 0) {
  console.log("True");
} else {
  console.log("False");
}